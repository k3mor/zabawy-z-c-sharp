﻿namespace Metody1
{
    internal class x
    {
    }
}